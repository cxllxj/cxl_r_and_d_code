#!/bin/bash
#run as below:
#   chmod 777 4.sh
#   ./4.sh or sh 4.sh
userName="xiaolong";
echo  "Hello,$userName"
echo  "Hello,${userName}"
echo  "Hello,$xiaolong"
echo  "${userName}"
echo  '${userName}'

#end

