#!/bin/bash
#run as below:
#   chmod 777 3.sh
#   ./3.sh p1 p2 p3 or sh 2.sh p1 p2 p3
#   the lasted line maybe has error

echo  "Program name is : " $0
echo  "Number of parameters is : " $#
echo  "The vlaue of last command is : " $?
echo  "Display all of parameters is : " $*
echo  "Display all of parameters is : " $@
echo  "The process ID is : " $$
echo  "The lasted process is : " $!


#end
