#!/bin/bash
#run as below:
#   chmod 777 7.sh
#   ./7.sh or sh 7.sh

echo  "Do you want some fruit? "
cat <<- FRUIT
  1) apple
  2) banana
FRUIT

echo "Please select fruit using digit:"
read choice
case ${choice} in 
  1)
    echo "You need apple."
    ;;
  2)
    echo "You need banana."
    ;;
  *)
    echo "No that fruit."
    ;;
esac
echo "Please visit next time."

#end
