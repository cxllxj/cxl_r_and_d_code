#!/bin/bash
#run as below:
#   chmod 777 2.sh
#   ./2.sh p1 p2 or sh 2.sh p1 p2

echo  "Program name is : " $0
echo  "The value of parameter 1 is : " $1
echo  "The value of parameter 2 is : " $2


#end
