#!/bin/bash
#run as below:
#   chmod 777 6.sh
#   ./6.sh or sh 6.sh

echo  "Say hello : "
for userN in wenjia wenzhong wenhua xiaolong
  do 
  echo "Hello,${userN}"
done

#end

