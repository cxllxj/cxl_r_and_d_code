#!/bin/bash
#run as below:
#   chmod 777 1.sh
#   ./1.sh or sh 1.sh

echo -n "Date and time is : "
date
echo -n "Your current directory is :"
pwd

#end

