#!/bin/bash
#run as below:
#   chmod 777 5.sh
#   ./5.sh or sh 5.sh

echo "Current user directory is : ${HOME}"
echo "Current shell path is : ${SHELL}"
echo "Current logged user name is : ${LOGNAME}"
echo "Current working  path is : ${PATH}"
echo "Current lang  is : ${LANG}"

#end
